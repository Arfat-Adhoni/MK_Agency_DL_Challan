import React from 'react'
import BillingApp from './pages/BillingApp'
const App = () => {
  return (
    <div>

      <BillingApp></BillingApp>



    </div>
  )
}

export default App