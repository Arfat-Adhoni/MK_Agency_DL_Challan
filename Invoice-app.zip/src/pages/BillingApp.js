import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import {
  Modal,
  Button,
  Table,
  Container,
  Row,
  Col,
  Form,
  Card,
} from "react-bootstrap";
import jsPDF from "jspdf";
import "jspdf-autotable";
import "./BillingApp.css";
import medicineOptions from "./MedicineInfo";
import CreatableSelect from "react-select/creatable";


const BillingApp = () => {
  const [items, setItems] = useState([]);
  const [newItem, setNewItem] = useState({ name: "", price: "", quantity: "" });
  const [editIndex, setEditIndex] = useState(null);
  const [showPopup, setShowPopup] = useState(false);
  const [clientName, setClientName] = useState("");
  const [referenceNo, setReferenceNo] = useState("");

  const formatDate = (date) => {
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, "0");
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = d.getFullYear();
    return `${day}/${month}/${year}`;
  };

  const formatDateTime = (date) => {
    const d = new Date(date);
    return `${formatDate(
      date
    )}_${d.getHours()}_${d.getMinutes()}_${d.getSeconds()}`;
  };

  const [invoiceDate, setInvoiceDate] = useState(formatDate(new Date()));
  const [errorMessage, setErrorMessage] = useState("");

  const handleDateChange = (e) => {
    const selectedDate = e.target.value;
    setInvoiceDate(formatDate(selectedDate));
  };

  const generatePDF = () => {
    if (!clientName || !referenceNo || items.length === 0) {
      setErrorMessage(
        "Please enter Client Name, Order No, and Add atleast one Medicine before generating the invoice."
      );
      return;
    }

    setErrorMessage(""); // Clear previous error
    const doc = new jsPDF();

    // Title
    doc.setFontSize(16);
    doc.setTextColor(0, 0, 255);
    doc.text("M/S M.K Agencies", 105, 15, { align: "center" });

    doc.setFontSize(12);
    doc.setTextColor(100);
    doc.text("Wholesale Distributors", 105, 22, { align: "center" });
    doc.text("Sainik School 2nd Gate", 105, 28, { align: "center" });
    doc.text("Athani Road, Vijayapur 586101", 105, 34, { align: "center" });

    doc.setLineWidth(0.5);
    doc.line(20, 40, 190, 40); // Horizontal line

    // Invoice Details
    const formattedDate = formatDate(new Date());
    const formattedDateTime = formatDateTime(new Date());

    doc.setTextColor(0);
    doc.text(`Name: ${clientName}`, 20, 50);
    doc.text(`Date: ${formattedDate}`, 20, 58);
    doc.text(`Reference No: ${referenceNo}`, 20, 66);

    doc.autoTable({
      head: [["Name", "Price", "Quantity", "Total"]],
      body: items.map((item) => [
        item.name,
        item.price,
        item.quantity,
        item.total,
      ]),
      startY: 75,
    });

    const totalAmount = `Total: ₹${items.reduce(
      (acc, item) => acc + item.total,
      0
    )}`;
    const pageWidth = doc.internal.pageSize.width;
    const totalX = pageWidth - 40; // Align with table's last column
    const totalY = doc.autoTable.previous.finalY + 10;
    doc.text(totalAmount, totalX, totalY, { align: "right" });

    // Save with dynamic filename: ClientName_FormatDateTime.pdf
    const fileName = `${clientName
      .replace(/\s+/g, "")
      .replace(/\//g, "-")}_Del-Challan_${formattedDateTime.replace(
      /\//g,
      "-"
    )}.pdf`;
    doc.save(fileName);
  };

  const handleAddItem = () => {
    if (!newItem.name || !newItem.price || !newItem.quantity) {
      setErrorMessage("Please add Medicine Name, Price & Quantity.");
      return;
    }
  
    setItems([...items, { ...newItem, total: newItem.price * newItem.quantity }]);
    setNewItem({ name: "", price: "", quantity: "" });
    setErrorMessage(""); // Clear error message on successful addition
  };
  

  const handleEdit = (index) => {
    setNewItem(items[index]);
    setEditIndex(index);
    setShowPopup(true);
  };

  const handleUpdateItem = () => {
    if (newItem.name && newItem.price && newItem.quantity) {
      const updatedItems = [...items];
      updatedItems[editIndex] = {
        ...newItem,
        total: newItem.price * newItem.quantity,
      };
      setItems(updatedItems);
      setNewItem({ name: "", price: "", quantity: "" });
      setEditIndex(null);
      setShowPopup(false);
    }
  };

  const handleDelete = (index) => setItems(items.filter((_, i) => i !== index));

  const calculateTotal = () => items.reduce((acc, item) => acc + item.total, 0);


  return (
    <Container className="py-4">
      <Card className="shadow-lg p-4">
        <h2 className="text-primary mb-2 text-center">M/S M.K Agencies</h2>
        <h5 className="text-muted text-center">Wholesale Distributors</h5>
        <h6 className="text-secondary text-center">Sainik School 2nd Gate</h6>
        <h6 className="text-secondary text-center">
          Athani Road, Vijayapur 586101
        </h6>
        <hr />

        <Row className="mb-3">
          <Col md={4}>
            <Form.Group>
              <Form.Label>Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter client name"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
              />
            </Form.Group>
          </Col>
          <Col md={4}>
            <Form.Group>
              <Form.Label>Order No</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Order number"
                value={referenceNo}
                onChange={(e) => setReferenceNo(e.target.value)}
              />
            </Form.Group>
          </Col>
          <Col md={4}>
            <Form.Group>
              <Form.Label>Date (MM/DD/YYYY)</Form.Label>
              <Form.Control
                type="date"
                value={invoiceDate.split("/").reverse().join("-")}
                onChange={handleDateChange}
              />
            </Form.Group>
          </Col>
        </Row>

        <Row className="mb-3">
          <Col md={4}>
          <Form.Group>
              <Form.Label>Medicine Name</Form.Label>
              <CreatableSelect
                options={medicineOptions}
                value={medicineOptions.find(option => option.value === newItem.name) || { label: newItem.name, value: newItem.name }}
                onChange={(selectedOption) => setNewItem({ ...newItem, name: selectedOption.value })}
                placeholder="Search or Enter Medicine"
                isSearchable
                isClearable
              />
            </Form.Group>
          </Col>
          <Col md={4}>
            <Form.Group>
              <Form.Label>Price</Form.Label>
              <Form.Control
                type="number"
                placeholder="Enter price"
                value={newItem.price}
                onChange={(e) =>
                  setNewItem({
                    ...newItem,
                    price: parseFloat(e.target.value) || "",
                  })
                }
              />
            </Form.Group>
          </Col>
          <Col md={4}>
            <Form.Group>
              <Form.Label>Quantity</Form.Label>
              <Form.Control
                type="number"
                placeholder="Enter quantity"
                value={newItem.quantity}
                onChange={(e) =>
                  setNewItem({
                    ...newItem,
                    quantity: parseInt(e.target.value) || "",
                  })
                }
              />
            </Form.Group>
          </Col>
        </Row>

        <Button variant="primary" onClick={handleAddItem} className="w-100">
          Add Item
        </Button>
        <Table striped bordered hover responsive className="mt-4">
          <thead className="bg-primary text-white">
            <tr>
              <th>Medicine Name</th>
              <th>Price</th>
              <th>Quantity</th>
              <th>Total</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, index) => (
              <tr key={index}>
                <td>{item.name}</td>
                <td>₹{item.price}</td>
                <td>{item.quantity}</td>
                <td>₹{item.total}</td>
                <td>
                  <Button
                    variant="warning"
                    size="sm"
                    className="me-2"
                    onClick={() => handleEdit(index)}
                  >
                    Edit
                  </Button>
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => handleDelete(index)}
                  >
                    Delete
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>

        {errorMessage && (
          <p className="text-danger text-center">{errorMessage}</p>
        )}

        <h4 className="text-end text-success">Total: ₹{calculateTotal()}</h4>
        <Button variant="success" onClick={generatePDF} className="mt-3 w-100">
          Generate Delivery Challan
        </Button>
      </Card>

      <Modal show={showPopup} onHide={() => setShowPopup(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Edit Item</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Form.Group>
            <Form.Label>Medicine Name</Form.Label>
            <CreatableSelect
              options={medicineOptions}
              value={medicineOptions.find(option => option.value === newItem.name) || { label: newItem.name, value: newItem.name }}
              onChange={(selectedOption) => setNewItem({ ...newItem, name: selectedOption.value })}
              placeholder="Search or Enter Medicine"
              isSearchable
              isClearable
            />
          </Form.Group>
          <Form.Group>
            <Form.Label>Price</Form.Label>
            <Form.Control
              type="number"
              value={newItem.price}
              onChange={(e) =>
                setNewItem({
                  ...newItem,
                  price: parseFloat(e.target.value) || "",
                })
              }
            />
          </Form.Group>
          <Form.Group>
            <Form.Label>Quantity</Form.Label>
            <Form.Control
              type="number"
              value={newItem.quantity}
              onChange={(e) =>
                setNewItem({
                  ...newItem,
                  quantity: parseInt(e.target.value) || "",
                })
              }
            />
          </Form.Group>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowPopup(false)}>
            Close
          </Button>
          <Button variant="primary" onClick={handleUpdateItem}>
            Update Item
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
};

export default BillingApp;
